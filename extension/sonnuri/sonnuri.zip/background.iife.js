(function() {let __HMR_ID = "0.mwevmiuul59";
(function () {
  'use strict';

  const LOCAL_RELOAD_SOCKET_PORT = 8081;
  const LOCAL_RELOAD_SOCKET_URL = `ws://localhost:${LOCAL_RELOAD_SOCKET_PORT}`;

  const DO_UPDATE = 'do_update';
  const DONE_UPDATE = 'done_update';

  class MessageInterpreter {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
     constructor() {}

    static send(message) {
      return JSON.stringify(message);
    }

    static receive(serializedMessage) {
      return JSON.parse(serializedMessage);
    }
  }

  function initClient({ id, onUpdate }) {
    const ws = new WebSocket(LOCAL_RELOAD_SOCKET_URL);

    ws.onopen = () => {
      ws.addEventListener('message', event => {
        const message = MessageInterpreter.receive(String(event.data));

        if (message.type === DO_UPDATE && message.id === id) {
          onUpdate();
          ws.send(MessageInterpreter.send({ type: DONE_UPDATE }));
          return;
        }
      });
    };
  }

  function addReload() {
    const reload = () => {
      chrome.runtime.reload();
    };

    initClient({
      // @ts-expect-error That's because of the dynamic code loading
      id: __HMR_ID,
      onUpdate: reload,
    });
  }

  addReload();

})();

})();
(function() {
  "use strict";
  let savedTexts = [];
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("백그라운드 메시지 수신");
    if (request.type === "open_side_panel") {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tabId = tabs[0].id;
        chrome.sidePanel.setOptions({
          tabId,
          path: "side-panel/index.html",
          enabled: true
          // 반드시 true로 설정해야 활성화됨
        });
        chrome.sidePanel.open({ tabId });
        savedTexts.push(request.text);
        chrome.storage.local.set({ savedTexts });
      });
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "get_saved_texts") {
      chrome.storage.local.get("savedTexts", (data) => {
        sendResponse(data.savedTexts || []);
      });
      return true;
    }
  });
})();
//# sourceMappingURL=background.iife.js.map
