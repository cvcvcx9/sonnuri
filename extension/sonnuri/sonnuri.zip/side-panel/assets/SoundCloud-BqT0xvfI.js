(function() {let __HMR_ID = "0.qey9fovgvn";
(function () {
  'use strict';

  const LOCAL_RELOAD_SOCKET_PORT = 8081;
  const LOCAL_RELOAD_SOCKET_URL = `ws://localhost:${LOCAL_RELOAD_SOCKET_PORT}`;

  const DO_UPDATE = 'do_update';
  const DONE_UPDATE = 'done_update';

  class MessageInterpreter {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
     constructor() {}

    static send(message) {
      return JSON.stringify(message);
    }

    static receive(serializedMessage) {
      return JSON.parse(serializedMessage);
    }
  }

  function initClient({ id, onUpdate }) {
    const ws = new WebSocket(LOCAL_RELOAD_SOCKET_URL);

    ws.onopen = () => {
      ws.addEventListener('message', event => {
        const message = MessageInterpreter.receive(String(event.data));

        if (message.type === DO_UPDATE && message.id === id) {
          onUpdate();
          ws.send(MessageInterpreter.send({ type: DONE_UPDATE }));
          return;
        }
      });
    };
  }

  function addRefresh() {
    let pendingReload = false;

    initClient({
      // @ts-expect-error That's because of the dynamic code loading
      id: __HMR_ID,
      onUpdate: () => {
        // disable reload when tab is hidden
        if (document.hidden) {
          pendingReload = true;
          return;
        }
        reload();
      },
    });

    // reload
    function reload() {
      pendingReload = false;
      window.location.reload();
    }

    // reload when tab is visible
    function reloadWhenTabIsVisible() {
      !document.hidden && pendingReload && reload();
    }

    document.addEventListener('visibilitychange', reloadWhenTabIsVisible);
  }

  addRefresh();

})();

})();
import { g as getDefaultExportFromCjs, r as reactExports, u as utils, p as patterns } from "./index-DH921Ai8.js";
function _mergeNamespaces(n, m) {
  for (var i = 0; i < m.length; i++) {
    const e = m[i];
    if (typeof e !== "string" && !Array.isArray(e)) {
      for (const k in e) {
        if (k !== "default" && !(k in n)) {
          const d = Object.getOwnPropertyDescriptor(e, k);
          if (d) {
            Object.defineProperty(n, k, d.get ? d : {
              enumerable: true,
              get: () => e[k]
            });
          }
        }
      }
    }
  }
  return Object.freeze(Object.defineProperty(n, Symbol.toStringTag, { value: "Module" }));
}
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
var SoundCloud_exports = {};
__export(SoundCloud_exports, {
  default: () => SoundCloud
});
var SoundCloud_1 = __toCommonJS(SoundCloud_exports);
var import_react = __toESM(reactExports);
var import_utils = utils;
var import_patterns = patterns;
const SDK_URL = "https://w.soundcloud.com/player/api.js";
const SDK_GLOBAL = "SC";
class SoundCloud extends import_react.Component {
  constructor() {
    super(...arguments);
    __publicField(this, "callPlayer", import_utils.callPlayer);
    __publicField(this, "duration", null);
    __publicField(this, "currentTime", null);
    __publicField(this, "fractionLoaded", null);
    __publicField(this, "mute", () => {
      this.setVolume(0);
    });
    __publicField(this, "unmute", () => {
      if (this.props.volume !== null) {
        this.setVolume(this.props.volume);
      }
    });
    __publicField(this, "ref", (iframe) => {
      this.iframe = iframe;
    });
  }
  componentDidMount() {
    this.props.onMount && this.props.onMount(this);
  }
  load(url, isReady) {
    (0, import_utils.getSDK)(SDK_URL, SDK_GLOBAL).then((SC) => {
      if (!this.iframe)
        return;
      const { PLAY, PLAY_PROGRESS, PAUSE, FINISH, ERROR } = SC.Widget.Events;
      if (!isReady) {
        this.player = SC.Widget(this.iframe);
        this.player.bind(PLAY, this.props.onPlay);
        this.player.bind(PAUSE, () => {
          const remaining = this.duration - this.currentTime;
          if (remaining < 0.05) {
            return;
          }
          this.props.onPause();
        });
        this.player.bind(PLAY_PROGRESS, (e) => {
          this.currentTime = e.currentPosition / 1e3;
          this.fractionLoaded = e.loadedProgress;
        });
        this.player.bind(FINISH, () => this.props.onEnded());
        this.player.bind(ERROR, (e) => this.props.onError(e));
      }
      this.player.load(url, {
        ...this.props.config.options,
        callback: () => {
          this.player.getDuration((duration) => {
            this.duration = duration / 1e3;
            this.props.onReady();
          });
        }
      });
    });
  }
  play() {
    this.callPlayer("play");
  }
  pause() {
    this.callPlayer("pause");
  }
  stop() {
  }
  seekTo(seconds, keepPlaying = true) {
    this.callPlayer("seekTo", seconds * 1e3);
    if (!keepPlaying) {
      this.pause();
    }
  }
  setVolume(fraction) {
    this.callPlayer("setVolume", fraction * 100);
  }
  getDuration() {
    return this.duration;
  }
  getCurrentTime() {
    return this.currentTime;
  }
  getSecondsLoaded() {
    return this.fractionLoaded * this.duration;
  }
  render() {
    const { display } = this.props;
    const style = {
      width: "100%",
      height: "100%",
      display
    };
    return /* @__PURE__ */ import_react.default.createElement(
      "iframe",
      {
        ref: this.ref,
        src: `https://w.soundcloud.com/player/?url=${encodeURIComponent(this.props.url)}`,
        style,
        frameBorder: 0,
        allow: "autoplay"
      }
    );
  }
}
__publicField(SoundCloud, "displayName", "SoundCloud");
__publicField(SoundCloud, "canPlay", import_patterns.canPlay.soundcloud);
__publicField(SoundCloud, "loopOnEnded", true);
const SoundCloud$1 = /* @__PURE__ */ getDefaultExportFromCjs(SoundCloud_1);
const SoundCloud$2 = /* @__PURE__ */ _mergeNamespaces({
  __proto__: null,
  default: SoundCloud$1
}, [SoundCloud_1]);
export {
  SoundCloud$2 as S
};
//# sourceMappingURL=SoundCloud-BqT0xvfI.js.map
